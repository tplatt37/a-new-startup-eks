How To Run

Local (PERMS: Your IAM User)
    Set environment variables locally
    npm start
    
    OR 

    ./scripts/start_server dev    (to pull from SSM)

Elastic Beanstalk (EC2) (PERMS: Instance Role used by EC2 Instance)
    Beanstalk sets environment variables in .ebextensions/options.config

CodeDeploy (EC2)  (PERMS: Instance Role you assign to the EC2 Instance)
    Run the template.yaml manually to create app infra - DynamoDB, SNS, SQS, SSM Params- all named "-dev"
    Your Deployment Group Name should be the name of the environment (i.e. dev)
    The "start_server" script will dynamically retrieve table name and other key environment values from SSM

Containerized (Local/ECS Task/EKS Pod)
    ECS Task - PERMS need to be set via Task Role (in Task Definition)
    EKS Pod - PERMS - need to use IRSA (not yet tested
    Local - you need to pass Env Vars in via --env (access key/secret access key)

    The relevant Env Vars need to be set via Task Definiton, Pod Spec, etc.
    If running containerized locally, you'll have to pass Env Vars in via --env

