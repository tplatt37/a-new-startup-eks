# Scripts

These scripts are intended to be used as CodeDeploy Hooks.  See the appspec.yml for details.

You only need these if deploying to EC2 via CodeDeploy.