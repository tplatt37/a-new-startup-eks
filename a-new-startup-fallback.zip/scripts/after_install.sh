#!/bin/bash

#
# This does nothing, but gives me an opportunity to talk about the "after" install" hook
#

echo "After Install..."
exit 0