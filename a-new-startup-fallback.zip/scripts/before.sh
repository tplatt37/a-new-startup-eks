#!/bin/bash

#
# This does nothing, but gives me an opportunity to talk about the "before install" hook
#

echo "Before Install..."
exit 0